<?php
require_once '../config/database.php';
require_once '../includes/session.php';
require_once '../includes/auth.php';
?>

<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;1,300;1,400&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --navy:#080C18;--navy2:#0F1526;--navy3:#161D35;--navy4:#1E2540;
  --gold:#C6973F;--gold2:#E8C27A;--cream:#EDE3C8;--muted:#8A8D9E;
  --border:rgba(198,151,63,0.18);--border2:rgba(198,151,63,0.30);
  --success:#3DAA73;--info:#4A8FCC;
}
body{font-family:'DM Sans',sans-serif;background:var(--navy);color:var(--cream);font-size:14px;overflow:hidden;height:520px;}
.layout{display:flex;height:520px;position:relative;}
.fabric-bg{position:fixed;inset:0;z-index:0;pointer-events:none;background-image:linear-gradient(rgba(198,151,63,.03)1px,transparent 1px),linear-gradient(90deg,rgba(198,151,63,.03)1px,transparent 1px);background-size:40px 40px;}

/* SIDEBAR */
.sb{width:220px;flex-shrink:0;background:var(--navy2);border-right:1px solid var(--border);display:flex;flex-direction:column;height:520px;overflow:hidden;position:relative;z-index:10;}
.sb-brand{display:flex;align-items:center;gap:10px;padding:16px 16px 14px;border-bottom:1px solid var(--border);}
.sb-logo{width:34px;height:34px;border-radius:9px;background:rgba(198,151,63,.08);border:1px solid var(--border);display:flex;align-items:center;justify-content:center;flex-shrink:0;}
.sb-title{font-family:'Cormorant Garamond',serif;font-size:16px;font-weight:400;color:var(--cream);}
.sb-sub{font-size:9px;color:var(--muted);letter-spacing:.15em;text-transform:uppercase;}
.sb-nav{flex:1;overflow:hidden;padding:12px 0;}
.sb-section{font-size:9px;font-weight:600;color:var(--muted);letter-spacing:.2em;text-transform:uppercase;padding:10px 16px 4px;}
.sb-item{display:flex;align-items:center;gap:10px;padding:9px 16px;text-decoration:none;color:var(--muted);font-size:12.5px;position:relative;transition:color .15s,background .15s;white-space:nowrap;}
.sb-item:hover{background:rgba(198,151,63,.06);color:var(--cream);}
.sb-item.active{background:rgba(198,151,63,.10);color:var(--gold2);}
.sb-item.active::before{content:'';position:absolute;left:0;top:4px;bottom:4px;width:3px;border-radius:0 3px 3px 0;background:var(--gold);}
.sb-item svg{width:16px;height:16px;flex-shrink:0;}
.sb-user{border-top:1px solid var(--border);padding:12px 16px;display:flex;align-items:center;gap:10px;cursor:pointer;}
.sb-avatar{width:32px;height:32px;border-radius:50%;background:rgba(198,151,63,.12);border:1.5px solid var(--border2);display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:600;color:var(--gold2);flex-shrink:0;}
.sb-uname{font-size:12px;font-weight:500;color:var(--cream);}
.sb-urole{font-size:10px;color:var(--muted);}

/* MAIN */
.main{flex:1;display:flex;flex-direction:column;overflow:hidden;position:relative;z-index:1;}
.topbar{height:52px;background:rgba(8,12,24,.85);border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;padding:0 22px;flex-shrink:0;}
.tb-left{display:flex;align-items:center;gap:12px;}
.toggle-btn{width:30px;height:30px;border-radius:7px;border:1px solid var(--border);background:rgba(198,151,63,.05);cursor:pointer;display:flex;align-items:center;justify-content:center;color:var(--muted);}
.tb-greet{font-size:12px;color:var(--muted);}
.tb-greet strong{color:var(--cream);font-weight:500;}
.tb-right{display:flex;align-items:center;gap:10px;}
.tb-badge{width:30px;height:30px;border-radius:7px;border:1px solid var(--border);background:rgba(198,151,63,.05);display:flex;align-items:center;justify-content:center;cursor:pointer;color:var(--muted);position:relative;}
.notif-dot{position:absolute;top:6px;right:6px;width:6px;height:6px;border-radius:50%;background:var(--gold);border:1.5px solid var(--navy);}
.tb-div{width:1px;height:20px;background:var(--border);}

/* PAGE */
.page{flex:1;overflow-y:auto;padding:18px 22px;scroll-behavior:smooth;}
.page::-webkit-scrollbar{width:4px;} .page::-webkit-scrollbar-track{background:transparent;} .page::-webkit-scrollbar-thumb{background:rgba(198,151,63,.2);border-radius:4px;}

/* Welcome */
.wb{background:var(--navy3);border:1px solid var(--border);border-radius:16px;padding:18px 22px;display:flex;align-items:center;justify-content:space-between;position:relative;overflow:hidden;margin-bottom:16px;animation:fadeUp .5s .05s both;}
.wb::before{content:'';position:absolute;top:0;left:0;right:0;bottom:0;background:linear-gradient(135deg,rgba(198,151,63,.06),transparent 60%);pointer-events:none;}
.wb-tape{position:absolute;bottom:-10px;right:20px;opacity:.07;transform:rotate(-3deg);width:180px;}
.wb-hello{font-family:'Cormorant Garamond',serif;font-size:22px;font-weight:300;color:var(--cream);}
.wb-hello em{color:var(--gold2);font-style:italic;}
.wb-sub{font-size:11px;color:var(--muted);margin-top:4px;}
.wb-sub strong{color:var(--gold2);}
.wb-btns{display:flex;gap:8px;z-index:1;}
.btn-p{padding:8px 14px;border:none;border-radius:8px;cursor:pointer;background:linear-gradient(135deg,#B8862E,#C9A84C,#DFC078,#C9A84C);color:#1a1200;font-size:11px;font-weight:500;letter-spacing:.04em;transition:transform .15s;box-shadow:0 3px 12px rgba(198,151,63,.25);}
.btn-p:hover{transform:translateY(-1px);}
.btn-g{padding:8px 14px;border:1px solid var(--border2);border-radius:8px;background:transparent;color:var(--cream);font-size:11px;cursor:pointer;transition:background .15s;}
.btn-g:hover{background:rgba(198,151,63,.08);}

/* Stats */
.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:16px;}
.sc{background:var(--navy3);border:1px solid var(--border);border-radius:12px;padding:14px 16px;position:relative;overflow:hidden;transition:border-color .2s,transform .2s;animation:fadeUp .5s both;}
.sc:nth-child(1){animation-delay:.1s}.sc:nth-child(2){animation-delay:.15s}.sc:nth-child(3){animation-delay:.2s}.sc:nth-child(4){animation-delay:.25s}
.sc:hover{border-color:var(--border2);transform:translateY(-2px);}
.sc::after{content:'';position:absolute;bottom:0;left:0;right:0;height:2px;background:linear-gradient(90deg,transparent,var(--gold),transparent);opacity:0;transition:opacity .2s;}
.sc:hover::after{opacity:.5;}
.si{width:32px;height:32px;border-radius:8px;background:rgba(198,151,63,.08);border:1px solid var(--border);display:flex;align-items:center;justify-content:center;margin-bottom:10px;}
.si.suc{background:rgba(61,170,115,.10);border-color:rgba(61,170,115,.25);}
.si.inf{background:rgba(74,143,204,.10);border-color:rgba(74,143,204,.25);}
.si svg{width:16px;height:16px;}
.sl{font-size:9px;font-weight:500;color:var(--muted);letter-spacing:.12em;text-transform:uppercase;}
.sn{font-family:'Cormorant Garamond',serif;font-size:30px;font-weight:300;color:var(--cream);line-height:1;margin-top:2px;}
.sn span{color:var(--gold2);}
.sh{font-size:10px;color:var(--muted);margin-top:4px;}

/* Main grid */
.mg{display:grid;grid-template-columns:1fr 260px;gap:14px;margin-bottom:14px;}
.panel{background:var(--navy3);border:1px solid var(--border);border-radius:12px;overflow:hidden;animation:fadeUp .5s both;}
.panel:nth-child(1){animation-delay:.3s}.panel:nth-child(2){animation-delay:.36s}
.ph{padding:13px 16px 11px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;}
.pt{font-family:'Cormorant Garamond',serif;font-size:16px;font-weight:400;color:var(--cream);display:flex;align-items:center;gap:7px;}
.pt svg{width:13px;height:13px;color:var(--gold);}
.pa{font-size:11px;color:var(--gold);cursor:pointer;border:none;background:none;font-family:'DM Sans',sans-serif;padding:0;}
.pb{padding:14px 16px;}

/* Orders table */
.ot{width:100%;border-collapse:collapse;}
.ot th{font-size:9px;font-weight:600;color:var(--muted);letter-spacing:.15em;text-transform:uppercase;padding:0 10px 8px 0;text-align:left;border-bottom:1px solid var(--border);}
.ot td{padding:10px 10px 10px 0;font-size:11.5px;color:var(--cream);border-bottom:1px solid rgba(198,151,63,.06);vertical-align:middle;}
.ot tr:last-child td{border-bottom:none;}
.ot tbody tr:hover td{background:rgba(198,151,63,.03);}
.oid{font-size:10px;color:var(--muted);}
.badge{display:inline-flex;align-items:center;gap:4px;padding:3px 8px;border-radius:20px;font-size:10px;font-weight:500;}
.bdot{width:5px;height:5px;border-radius:50%;}
.completed{background:rgba(61,170,115,.12);color:#5DD49A;border:1px solid rgba(61,170,115,.2);}
.in_progress{background:rgba(74,143,204,.12);color:#7BBDE8;border:1px solid rgba(74,143,204,.2);}
.ready{background:rgba(198,151,63,.12);color:var(--gold2);border:1px solid rgba(198,151,63,.25);}
.bdot.completed{background:#5DD49A;} .bdot.in_progress{background:#7BBDE8;} .bdot.ready{background:var(--gold2);}

/* Progress steps */
.oir{display:flex;align-items:center;gap:7px;padding:8px 10px;background:rgba(198,151,63,.04);border:1px solid rgba(198,151,63,.12);border-radius:8px;margin-bottom:12px;}
.oir svg{width:12px;height:12px;color:var(--gold);}
.oit{font-size:11px;color:var(--muted);}
.oit strong{color:var(--cream);font-weight:500;}
.pi{display:flex;align-items:flex-start;gap:10px;padding:8px 0;}
.pi:not(:last-child){border-bottom:1px solid rgba(198,151,63,.05);}
.scol{display:flex;flex-direction:column;align-items:center;flex-shrink:0;}
.sc2{width:22px;height:22px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:9px;font-weight:600;flex-shrink:0;}
.sc2.done{background:rgba(61,170,115,.15);border:1.5px solid #3DAA73;color:#5DD49A;}
.sc2.active{background:rgba(198,151,63,.15);border:1.5px solid var(--gold);color:var(--gold2);animation:sp 2s ease-in-out infinite;}
.sc2.pend{background:rgba(138,141,158,.08);border:1.5px solid rgba(138,141,158,.2);color:var(--muted);}
@keyframes sp{0%,100%{box-shadow:0 0 6px rgba(198,151,63,.2)}50%{box-shadow:0 0 14px rgba(198,151,63,.45)}}
.scon{width:1.5px;height:14px;margin:2px 0;background:linear-gradient(to bottom,rgba(198,151,63,.3),rgba(198,151,63,.06));}
.sct{padding-top:2px;}
.sn2{font-size:11.5px;font-weight:500;}.sn2.done{color:var(--muted);}.sn2.active{color:var(--gold2);}.sn2.pend{color:var(--muted);font-weight:400;}
.sd{font-size:10px;color:var(--muted);margin-top:1px;}

/* Bottom grid */
.bg2{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;}
.bg2 .panel:nth-child(1){animation-delay:.42s}.bg2 .panel:nth-child(2){animation-delay:.48s}.bg2 .panel:nth-child(3){animation-delay:.54s}

/* QA */
.qa{display:grid;grid-template-columns:1fr 1fr;gap:8px;}
.qa-b{display:flex;flex-direction:column;align-items:flex-start;gap:5px;padding:10px;border-radius:10px;border:1px solid var(--border);background:rgba(198,151,63,.03);cursor:pointer;text-decoration:none;transition:background .15s,transform .15s;}
.qa-b:hover{background:rgba(198,151,63,.08);border-color:var(--border2);transform:translateY(-2px);}
.qa-ic{width:28px;height:28px;border-radius:7px;background:rgba(198,151,63,.08);border:1px solid var(--border);display:flex;align-items:center;justify-content:center;}
.qa-ic svg{width:13px;height:13px;}
.ql{font-size:11px;font-weight:500;color:var(--cream);}
.qs{font-size:10px;color:var(--muted);}

/* Appointment */
.ac{background:rgba(198,151,63,.05);border:1px solid rgba(198,151,63,.2);border-radius:10px;padding:12px;position:relative;overflow:hidden;}
.ac::before{content:'';position:absolute;top:0;left:0;right:0;height:2px;background:linear-gradient(90deg,transparent,var(--gold),transparent);}
.ad{font-family:'Cormorant Garamond',serif;font-size:18px;font-weight:300;color:var(--cream);}
.at{font-size:12px;color:var(--gold2);margin-top:2px;font-weight:500;}
.am{margin-top:10px;display:flex;flex-direction:column;gap:4px;}
.ar{display:flex;align-items:center;gap:6px;font-size:11px;color:var(--muted);}
.ar svg{width:11px;height:11px;color:var(--gold);}

/* Measurements */
.mr{display:flex;align-items:center;justify-content:space-between;padding:7px 0;border-bottom:1px solid rgba(198,151,63,.07);font-size:11.5px;}
.mr:last-child{border-bottom:none;}
.ml{color:var(--muted);}
.mv{font-weight:500;color:var(--cream);}
.mu{font-size:9px;color:var(--muted);}

@keyframes fadeUp{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:translateY(0)}}
</style>

<div class="fabric-bg"></div>
<div class="layout">

<!-- SIDEBAR -->
<aside class="sb">
  <div class="sb-brand">
    <div class="sb-logo">
      <svg width="18" height="20" viewBox="0 0 60 70" fill="none">
        <rect x="4" y="0" width="52" height="13" rx="4" fill="none" stroke="#C6973F" stroke-width="2.5"/>
        <rect x="4" y="57" width="52" height="13" rx="4" fill="none" stroke="#C6973F" stroke-width="2.5"/>
        <rect x="16" y="13" width="28" height="44" rx="2" fill="none" stroke="#C6973F" stroke-width="2"/>
        <line x1="16" y1="22" x2="44" y2="22" stroke="#C6973F" stroke-width="1.2" opacity=".6"/>
        <line x1="16" y1="30" x2="44" y2="30" stroke="#C6973F" stroke-width="1.2" opacity=".6"/>
        <line x1="16" y1="38" x2="44" y2="38" stroke="#C6973F" stroke-width="1.2" opacity=".6"/>
        <line x1="16" y1="46" x2="44" y2="46" stroke="#C6973F" stroke-width="1.2" opacity=".6"/>
      </svg>
    </div>
    <div><div class="sb-title">Atelier</div><div class="sb-sub">Management</div></div>
  </div>
  <nav class="sb-nav">
    <div class="sb-section">Main</div>
    <a href="#" class="sb-item active">
      <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.6"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/></svg>
      Dashboard
    </a>
    <a href="#" class="sb-item">
      <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.6"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2"/><rect x="9" y="3" width="6" height="4" rx="1"/><path d="M9 12h6M9 16h4" stroke-linecap="round"/></svg>
      My Orders
    </a>
    <a href="#" class="sb-item">
      <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.6"><path d="M12 5v14M5 12h14" stroke-linecap="round"/></svg>
      New Order
    </a>
    <div class="sb-section">Profile</div>
    <a href="#" class="sb-item">
      <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.6"><rect x="2" y="9" width="20" height="6" rx="2"/><path d="M6 9V7M10 9V7M14 9V7M18 9V7" stroke-linecap="round"/></svg>
      Measurements
    </a>
    <a href="#" class="sb-item">
      <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.6"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18" stroke-linecap="round"/></svg>
      Appointments
    </a>
    <a href="#" class="sb-item">
      <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.6"><circle cx="12" cy="8" r="4"/><path d="M4 20c0-4 3.6-7 8-7s8 3 8 7" stroke-linecap="round"/></svg>
      My Profile
    </a>
  </nav>
  <div class="sb-user">
    <div class="sb-avatar">AK</div>
    <div><div class="sb-uname">Ahmed Khan</div><div class="sb-urole">Client Account</div></div>
  </div>
</aside>

<!-- MAIN -->
<div class="main">
  <header class="topbar">
    <div class="tb-left">
      <button class="toggle-btn" id="tb">
        <svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path d="M4 6h16M4 12h16M4 18h16" stroke-linecap="round"/></svg>
      </button>
      <span class="tb-greet">Good Afternoon, <strong>Ahmed</strong></span>
    </div>
    <div class="tb-right">
      <div class="tb-badge"><div class="notif-dot"></div>
        <svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.7"><path d="M15 17H9m9-7A6 6 0 106 10c0 3.5-.9 5.5-2 7h16c-1.1-1.5-2-3.5-2-7z" stroke-linecap="round"/></svg>
      </div>
      <div class="tb-div"></div>
      <div class="sb-avatar" style="width:28px;height:28px;font-size:10px;cursor:pointer;">AK</div>
    </div>
  </header>

  <div class="page">
    <!-- Welcome -->
    <div class="wb">
      <div>
        <h1 class="wb-hello">Welcome back, <em>Ahmed</em></h1>
        <p class="wb-sub">You have <strong>3 active orders</strong> · Next fitting: Monday, 19 May</p>
      </div>
      <div class="wb-btns">
        <button class="btn-g">Book Fitting</button>
        <button class="btn-p">+ New Order</button>
      </div>
      <svg class="wb-tape" viewBox="0 0 280 28" fill="none">
        <rect x="0" y="4" width="280" height="20" rx="3" fill="none" stroke="#C6973F" stroke-width="1.5"/>
        <line x1="0" y1="4" x2="0" y2="24" stroke="#C6973F" stroke-width="1" opacity=".7"/>
        <line x1="10" y1="4" x2="10" y2="16" stroke="#C6973F" stroke-width="1" opacity=".6"/>
        <line x1="20" y1="4" x2="20" y2="16" stroke="#C6973F" stroke-width="1" opacity=".6"/>
        <line x1="30" y1="4" x2="30" y2="16" stroke="#C6973F" stroke-width="1" opacity=".6"/>
        <line x1="40" y1="4" x2="40" y2="16" stroke="#C6973F" stroke-width="1" opacity=".6"/>
        <line x1="50" y1="4" x2="50" y2="24" stroke="#C6973F" stroke-width="1" opacity=".7"/>
        <line x1="60" y1="4" x2="60" y2="16" stroke="#C6973F" stroke-width="1" opacity=".6"/>
        <line x1="70" y1="4" x2="70" y2="16" stroke="#C6973F" stroke-width="1" opacity=".6"/>
        <line x1="80" y1="4" x2="80" y2="16" stroke="#C6973F" stroke-width="1" opacity=".6"/>
        <line x1="90" y1="4" x2="90" y2="16" stroke="#C6973F" stroke-width="1" opacity=".6"/>
        <line x1="100" y1="4" x2="100" y2="24" stroke="#C6973F" stroke-width="1" opacity=".7"/>
        <line x1="110" y1="4" x2="110" y2="16" stroke="#C6973F" stroke-width="1" opacity=".6"/>
        <line x1="120" y1="4" x2="120" y2="16" stroke="#C6973F" stroke-width="1" opacity=".6"/>
        <line x1="130" y1="4" x2="130" y2="16" stroke="#C6973F" stroke-width="1" opacity=".6"/>
        <line x1="140" y1="4" x2="140" y2="16" stroke="#C6973F" stroke-width="1" opacity=".6"/>
        <line x1="150" y1="4" x2="150" y2="24" stroke="#C6973F" stroke-width="1" opacity=".7"/>
        <line x1="160" y1="4" x2="160" y2="16" stroke="#C6973F" stroke-width="1" opacity=".6"/>
        <line x1="170" y1="4" x2="170" y2="16" stroke="#C6973F" stroke-width="1" opacity=".6"/>
        <line x1="180" y1="4" x2="180" y2="16" stroke="#C6973F" stroke-width="1" opacity=".6"/>
        <line x1="190" y1="4" x2="190" y2="16" stroke="#C6973F" stroke-width="1" opacity=".6"/>
        <line x1="200" y1="4" x2="200" y2="24" stroke="#C6973F" stroke-width="1" opacity=".7"/>
        <line x1="210" y1="4" x2="210" y2="16" stroke="#C6973F" stroke-width="1" opacity=".6"/>
        <line x1="220" y1="4" x2="220" y2="16" stroke="#C6973F" stroke-width="1" opacity=".6"/>
        <line x1="230" y1="4" x2="230" y2="16" stroke="#C6973F" stroke-width="1" opacity=".6"/>
        <line x1="240" y1="4" x2="240" y2="16" stroke="#C6973F" stroke-width="1" opacity=".6"/>
        <line x1="250" y1="4" x2="250" y2="24" stroke="#C6973F" stroke-width="1" opacity=".7"/>
        <line x1="260" y1="4" x2="260" y2="16" stroke="#C6973F" stroke-width="1" opacity=".6"/>
        <line x1="270" y1="4" x2="270" y2="16" stroke="#C6973F" stroke-width="1" opacity=".6"/>
        <line x1="280" y1="4" x2="280" y2="24" stroke="#C6973F" stroke-width="1" opacity=".7"/>
      </svg>
    </div>

    <!-- Stats -->
    <div class="stats">
      <div class="sc">
        <div class="si"><svg fill="none" viewBox="0 0 24 24" stroke="#C6973F" stroke-width="1.6"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2"/><rect x="9" y="3" width="6" height="4" rx="1"/></svg></div>
        <div class="sl">Active Orders</div>
        <div class="sn"><span class="cu" data-t="3">0</span></div>
        <div class="sh">In progress now</div>
      </div>
      <div class="sc">
        <div class="si suc"><svg fill="none" viewBox="0 0 24 24" stroke="#3DAA73" stroke-width="1.6"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" stroke-linecap="round"/></svg></div>
        <div class="sl">Completed</div>
        <div class="sn"><span class="cu" data-t="12">0</span></div>
        <div class="sh">Total delivered</div>
      </div>
      <div class="sc">
        <div class="si"><svg fill="none" viewBox="0 0 24 24" stroke="#C6973F" stroke-width="1.6"><rect x="2" y="9" width="20" height="6" rx="2"/><path d="M6 9V7M10 9V7M14 9V7M18 9V7" stroke-linecap="round"/></svg></div>
        <div class="sl">Measurements</div>
        <div class="sn"><span class="cu" data-t="2">0</span></div>
        <div class="sh">Saved profiles</div>
      </div>
      <div class="sc">
        <div class="si inf"><svg fill="none" viewBox="0 0 24 24" stroke="#4A8FCC" stroke-width="1.6"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18" stroke-linecap="round"/><circle cx="12" cy="16" r="1.5" fill="#4A8FCC"/></svg></div>
        <div class="sl">Appointments</div>
        <div class="sn"><span class="cu" data-t="1">0</span></div>
        <div class="sh">Upcoming</div>
      </div>
    </div>

    <!-- Main grid -->
    <div class="mg">
      <!-- Orders -->
      <div class="panel">
        <div class="ph">
          <div class="pt"><svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.6"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2"/><rect x="9" y="3" width="6" height="4" rx="1"/></svg>Recent Orders</div>
          <button class="pa">View all →</button>
        </div>
        <div class="pb" style="padding-top:10px">
          <table class="ot">
            <thead><tr><th>Item</th><th>Date</th><th>Status</th></tr></thead>
            <tbody>
              <tr><td><div style="font-size:12px;font-weight:500">Three-Piece Suit</div><div class="oid">ORD-1042</div></td><td style="color:var(--muted);font-size:11px">10 May</td><td><span class="badge in_progress"><span class="bdot in_progress"></span>In Progress</span></td></tr>
              <tr><td><div style="font-size:12px;font-weight:500">Dress Shirt (×3)</div><div class="oid">ORD-1039</div></td><td style="color:var(--muted);font-size:11px">02 May</td><td><span class="badge ready"><span class="bdot ready"></span>Ready</span></td></tr>
              <tr><td><div style="font-size:12px;font-weight:500">Sherwani</div><div class="oid">ORD-1031</div></td><td style="color:var(--muted);font-size:11px">18 Apr</td><td><span class="badge completed"><span class="bdot completed"></span>Completed</span></td></tr>
              <tr><td><div style="font-size:12px;font-weight:500">Casual Trousers (×2)</div><div class="oid">ORD-1028</div></td><td style="color:var(--muted);font-size:11px">10 Apr</td><td><span class="badge completed"><span class="bdot completed"></span>Completed</span></td></tr>
            </tbody>
          </table>
        </div>
      </div>
      <!-- Progress -->
      <div class="panel">
        <div class="ph">
          <div class="pt"><svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.6"><circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3" stroke-linecap="round"/></svg>Active Order</div>
          <button class="pa">Details →</button>
        </div>
        <div class="pb">
          <div class="oir"><svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.7"><path d="M7 7h10M7 11h7" stroke-linecap="round"/><rect x="3" y="3" width="18" height="18" rx="2"/></svg><span class="oit"><strong>ORD-1042</strong> — Three-Piece Suit</span></div>
          <div class="pi"><div class="scol"><div class="sc2 done"><svg width="10" height="10" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path d="M5 13l4 4L19 7" stroke-linecap="round"/></svg></div><div class="scon"></div></div><div class="sct"><div class="sn2 done">Measurement</div><div class="sd">Submitted & confirmed</div></div></div>
          <div class="pi"><div class="scol"><div class="sc2 done"><svg width="10" height="10" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path d="M5 13l4 4L19 7" stroke-linecap="round"/></svg></div><div class="scon"></div></div><div class="sct"><div class="sn2 done">Fabric Cut</div><div class="sd">Fabric selected & cut</div></div></div>
          <div class="pi"><div class="scol"><div class="sc2 active"><svg width="8" height="8" viewBox="0 0 10 10"><circle cx="5" cy="5" r="3.5" fill="#C6973F"/></svg></div><div class="scon"></div></div><div class="sct"><div class="sn2 active">Stitching</div><div class="sd">Master tailor stitching</div></div></div>
          <div class="pi"><div class="scol"><div class="sc2 pend"><span>4</span></div><div class="scon"></div></div><div class="sct"><div class="sn2 pend">Fitting</div><div class="sd">Client fitting session</div></div></div>
          <div class="pi"><div class="scol"><div class="sc2 pend"><span>5</span></div><div class="scon"></div></div><div class="sct"><div class="sn2 pend">Final Press</div><div class="sd">Quality check</div></div></div>
          <div class="pi"><div class="scol"><div class="sc2 pend"><span>6</span></div></div><div class="sct"><div class="sn2 pend">Ready</div><div class="sd">Ready for collection</div></div></div>
        </div>
      </div>
    </div>

    <!-- Bottom grid -->
    <div class="bg2">
      <!-- Quick actions -->
      <div class="panel">
        <div class="ph"><div class="pt"><svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.6"><path d="M13 10V3L4 14h7v7l9-11h-7z" stroke-linecap="round"/></svg>Quick Actions</div></div>
        <div class="pb">
          <div class="qa">
            <a href="#" class="qa-b"><div class="qa-ic"><svg fill="none" viewBox="0 0 24 24" stroke="#C6973F" stroke-width="1.7"><path d="M12 5v14M5 12h14" stroke-linecap="round"/></svg></div><div class="ql">New Order</div><div class="qs">Place a request</div></a>
            <a href="#" class="qa-b"><div class="qa-ic"><svg fill="none" viewBox="0 0 24 24" stroke="#C6973F" stroke-width="1.7"><rect x="2" y="9" width="20" height="6" rx="2"/><path d="M6 9V7M10 9V7M14 9V7M18 9V7" stroke-linecap="round"/></svg></div><div class="ql">Measurements</div><div class="qs">View or update</div></a>
            <a href="#" class="qa-b"><div class="qa-ic"><svg fill="none" viewBox="0 0 24 24" stroke="#C6973F" stroke-width="1.7"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18" stroke-linecap="round"/></svg></div><div class="ql">Book Fitting</div><div class="qs">Schedule now</div></a>
            <a href="#" class="qa-b"><div class="qa-ic"><svg fill="none" viewBox="0 0 24 24" stroke="#C6973F" stroke-width="1.7"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" stroke-linecap="round"/></svg></div><div class="ql">Track Order</div><div class="qs">Live progress</div></a>
          </div>
        </div>
      </div>
      <!-- Appointment -->
      <div class="panel">
        <div class="ph"><div class="pt"><svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.6"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18" stroke-linecap="round"/></svg>Appointment</div><button class="pa">All →</button></div>
        <div class="pb">
          <div class="ac">
            <div class="ac::before"></div>
            <div class="ad">Monday, 19 May 2026</div>
            <div class="at">⏰ 3:00 PM</div>
            <div class="am">
              <div class="ar"><svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.7"><path d="M7 7h10M7 11h7" stroke-linecap="round"/><rect x="3" y="3" width="18" height="18" rx="2"/></svg>Fitting Session</div>
              <div class="ar"><svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.7"><circle cx="12" cy="8" r="4"/><path d="M4 20c0-4 3.6-7 8-7s8 3 8 7" stroke-linecap="round"/></svg>with Master Khalid</div>
            </div>
          </div>
          <button class="btn-g" style="width:100%;margin-top:10px;font-size:11px;justify-content:center;border-radius:8px;padding:7px">Add to Calendar</button>
        </div>
      </div>
      <!-- Measurements -->
      <div class="panel">
        <div class="ph"><div class="pt"><svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.6"><rect x="2" y="9" width="20" height="6" rx="2"/><path d="M6 9V7M10 9V7M14 9V7M18 9V7" stroke-linecap="round"/></svg>Measurements</div><button class="pa">Edit →</button></div>
        <div class="pb" style="padding-top:8px">
          <div class="mr"><span class="ml">Chest</span><span class="mv">42<span class="mu"> in</span></span></div>
          <div class="mr"><span class="ml">Waist</span><span class="mv">36<span class="mu"> in</span></span></div>
          <div class="mr"><span class="ml">Hips</span><span class="mv">40<span class="mu"> in</span></span></div>
          <div class="mr"><span class="ml">Shoulder</span><span class="mv">17<span class="mu"> in</span></span></div>
          <div class="mr"><span class="ml">Sleeve</span><span class="mv">25<span class="mu"> in</span></span></div>
          <div class="mr"><span class="ml">Inseam</span><span class="mv">32<span class="mu"> in</span></span></div>
        </div>
      </div>
    </div>

  </div><!-- /page -->
</div><!-- /main -->
</div><!-- /layout -->

<script>
document.querySelectorAll('.cu').forEach(el => {
  const target = parseInt(el.dataset.t);
  const start = performance.now();
  const dur = 1200;
  const run = now => {
    const t = Math.min((now-start)/dur,1);
    const ease = 1-Math.pow(1-t,3);
    el.textContent = Math.round(ease*target);
    if(t<1) requestAnimationFrame(run);
  };
  setTimeout(()=>requestAnimationFrame(run), 400);
});
document.querySelectorAll('.sb-item').forEach(i=>{
  i.addEventListener('click',e=>{e.preventDefault();document.querySelectorAll('.sb-item').forEach(x=>x.classList.remove('active'));i.classList.add('active');});
});
</script>
