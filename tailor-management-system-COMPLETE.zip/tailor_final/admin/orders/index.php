<?php
require_once '../../includes/auth.php';
require_once '../../config/database.php';
require_once '../../includes/header.php';
$result=mysqli_query($conn,"SELECT o.*,c.customer_name FROM orders o JOIN customers c ON o.customer_id=c.id ORDER BY o.id DESC");
$badges=['Pending'=>'badge-pending','In Progress'=>'badge-progress','Ready'=>'badge-ready','Delivered'=>'badge-delivered','Cancelled'=>'badge-cancelled'];
?>
<?php include '../../includes/navbar.php';?>
<div class="app-layout">
<?php include '../../includes/sidebar.php';?>
<div class="main-wrap"><div class="page-content">
<div class="page-header">
  <div class="breadcrumb-bar"><a href="../dashboard.php">Home</a><span class="sep">/</span><span>Orders</span></div>
  <h2>Orders</h2>
</div>
<?php if(isset($_SESSION['success'])):?>
<div class="alert-tms alert-success-tms"><i class="bi bi-check-circle"></i><?php echo $_SESSION['success'];unset($_SESSION['success']);?></div>
<?php endif;?>
<div class="tms-card">
  <div class="tms-card-header">
    <h5><i class="bi bi-bag-check me-2" style="color:var(--gold2)"></i>All Orders</h5>
    <a href="create.php" class="btn-tms btn-gold"><i class="bi bi-plus-lg"></i> Create Order</a>
  </div>
  <div class="tms-table-wrap">
    <table class="tms-table">
      <thead><tr><th>#</th><th>Customer</th><th>Dress</th><th>Total</th><th>Advance</th><th>Remaining</th><th>Status</th><th>Delivery</th><th>Actions</th></tr></thead>
      <tbody>
      <?php if($result && mysqli_num_rows($result)>0): while($row=mysqli_fetch_assoc($result)): $bc=$badges[$row['order_status']]??'badge-pending';?>
      <tr>
        <td style="color:var(--muted)">#<?php echo $row['id'];?></td>
        <td><strong><?php echo htmlspecialchars($row['customer_name']);?></strong></td>
        <td><?php echo htmlspecialchars($row['dress_type']);?></td>
        <td>Rs <?php echo number_format($row['total_amount']);?></td>
        <td style="color:var(--gold2)">Rs <?php echo number_format($row['advance_payment']);?></td>
        <td style="color:#e07070"><strong>Rs <?php echo number_format($row['remaining_amount']);?></strong></td>
        <td><span class="badge-tms <?php echo $bc;?>"><?php echo $row['order_status'];?></span></td>
        <td style="color:var(--muted)"><?php echo $row['delivery_date']?date('d M Y',strtotime($row['delivery_date'])):'—';?></td>
        <td style="display:flex;gap:5px;">
          <a href="view.php?id=<?php echo $row['id'];?>" class="btn-tms btn-info-tms btn-sm-tms"><i class="bi bi-eye"></i></a>
          <a href="edit.php?id=<?php echo $row['id'];?>" class="btn-tms btn-ghost btn-sm-tms"><i class="bi bi-pencil"></i></a>
          <a href="invoice.php?id=<?php echo $row['id'];?>" class="btn-tms btn-ghost btn-sm-tms" title="Invoice"><i class="bi bi-receipt"></i></a>
          <a href="delete.php?id=<?php echo $row['id'];?>" class="btn-tms btn-danger-tms btn-sm-tms" onclick="return confirm('Delete this order?')"><i class="bi bi-trash"></i></a>
        </td>
      </tr>
      <?php endwhile; else:?>
      <tr><td colspan="9"><div class="empty-state"><i class="bi bi-bag-x"></i><p>No orders found</p></div></td></tr>
      <?php endif;?>
      </tbody>
    </table>
  </div>
</div>
</div></div></div>
<?php require_once '../../includes/footer.php';?>
