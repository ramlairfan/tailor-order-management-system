<?php
require_once '../../includes/auth.php';
require_once '../../config/database.php';
require_once '../../includes/header.php';
$id=(int)($_GET['id']??0);
$data=mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM orders WHERE id=$id"));
if(!$data){header("Location: index.php");exit;}
if($_SERVER['REQUEST_METHOD']=='POST'){
  $cid    =(int)$_POST['customer_id'];
  $dress  =mysqli_real_escape_string($conn,trim($_POST['dress_type']));
  $fabric =mysqli_real_escape_string($conn,trim($_POST['fabric_type']??''));
  $qty    =(int)$_POST['quantity'];
  $total  =(float)$_POST['total_amount'];
  $advance=(float)$_POST['advance_payment'];
  $remain =$total-$advance;
  $odate  =mysqli_real_escape_string($conn,$_POST['order_date']);
  $ddate  =mysqli_real_escape_string($conn,$_POST['delivery_date']??'');
  $status =mysqli_real_escape_string($conn,$_POST['order_status']);
  $notes  =mysqli_real_escape_string($conn,trim($_POST['notes']??''));
  mysqli_query($conn,"UPDATE orders SET customer_id=$cid,dress_type='$dress',fabric_type='$fabric',quantity=$qty,total_amount=$total,advance_payment=$advance,remaining_amount=$remain,order_status='$status',order_date='$odate',delivery_date='$ddate',notes='$notes' WHERE id=$id");
  $_SESSION['success']="Order updated.";header("Location: index.php");exit;
}
$customers=mysqli_query($conn,"SELECT id,customer_name FROM customers ORDER BY customer_name");
?>
<?php include '../../includes/navbar.php';?>
<div class="app-layout">
<?php include '../../includes/sidebar.php';?>
<div class="main-wrap"><div class="page-content">
<div class="page-header">
  <div class="breadcrumb-bar"><a href="../dashboard.php">Home</a><span class="sep">/</span><a href="index.php">Orders</a><span class="sep">/</span><span>Edit</span></div>
  <h2>Edit Order #<?php echo $id;?></h2>
</div>
<div class="tms-card" style="max-width:700px;">
  <div class="tms-card-header"><h5><i class="bi bi-pencil-square me-2" style="color:var(--gold2)"></i>Edit Details</h5></div>
  <div class="tms-card-body">
    <form method="POST">
      <div class="form-group"><label class="form-label-tms">Customer</label>
        <select name="customer_id" class="form-control-tms">
          <?php while($c=mysqli_fetch_assoc($customers)):?>
          <option value="<?php echo $c['id'];?>" <?php if($c['id']==$data['customer_id']) echo 'selected';?>><?php echo htmlspecialchars($c['customer_name']);?></option>
          <?php endwhile;?>
        </select></div>
      <div class="form-row">
        <div class="form-group"><label class="form-label-tms">Dress Type</label>
          <input type="text" name="dress_type" class="form-control-tms" value="<?php echo htmlspecialchars($data['dress_type']);?>"></div>
        <div class="form-group"><label class="form-label-tms">Fabric Type</label>
          <input type="text" name="fabric_type" class="form-control-tms" value="<?php echo htmlspecialchars($data['fabric_type']??'');?>"></div>
      </div>
      <div class="form-row-3">
        <div class="form-group"><label class="form-label-tms">Quantity</label>
          <input type="number" name="quantity" class="form-control-tms" value="<?php echo $data['quantity'];?>"></div>
        <div class="form-group"><label class="form-label-tms">Total (Rs)</label>
          <input type="number" name="total_amount" class="form-control-tms" value="<?php echo $data['total_amount'];?>" step="0.01"></div>
        <div class="form-group"><label class="form-label-tms">Advance (Rs)</label>
          <input type="number" name="advance_payment" class="form-control-tms" value="<?php echo $data['advance_payment'];?>" step="0.01"></div>
      </div>
      <div class="form-row">
        <div class="form-group"><label class="form-label-tms">Order Date</label>
          <input type="date" name="order_date" class="form-control-tms" value="<?php echo $data['order_date'];?>"></div>
        <div class="form-group"><label class="form-label-tms">Delivery Date</label>
          <input type="date" name="delivery_date" class="form-control-tms" value="<?php echo $data['delivery_date']??'';?>"></div>
      </div>
      <div class="form-group"><label class="form-label-tms">Status</label>
        <select name="order_status" class="form-control-tms">
          <?php foreach(['Pending','In Progress','Ready','Delivered','Cancelled'] as $s):?>
          <option <?php if($data['order_status']==$s) echo 'selected';?>><?php echo $s;?></option>
          <?php endforeach;?>
        </select></div>
      <div class="form-group"><label class="form-label-tms">Notes</label>
        <textarea name="notes" class="form-control-tms" rows="2"><?php echo htmlspecialchars($data['notes']??'');?></textarea></div>
      <div style="display:flex;gap:12px;">
        <button type="submit" class="btn-tms btn-gold"><i class="bi bi-check-lg"></i> Update</button>
        <a href="index.php" class="btn-tms btn-ghost"><i class="bi bi-x"></i> Cancel</a>
      </div>
    </form>
  </div>
</div>
</div></div></div>
<?php require_once '../../includes/footer.php';?>
