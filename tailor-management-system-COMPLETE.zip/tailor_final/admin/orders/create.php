<?php
require_once '../../includes/auth.php';
require_once '../../config/database.php';
require_once '../../includes/header.php';
$error='';
if($_SERVER['REQUEST_METHOD']=='POST'){
  $cid    =(int)$_POST['customer_id'];
  $dress  =mysqli_real_escape_string($conn,trim($_POST['dress_type']));
  $fabric =mysqli_real_escape_string($conn,trim($_POST['fabric_type']??''));
  $qty    =(int)($_POST['quantity']??1);
  $total  =(float)($_POST['total_amount']??0);
  $advance=(float)($_POST['advance_payment']??0);
  $remain =$total-$advance;
  $odate  =mysqli_real_escape_string($conn,$_POST['order_date']);
  $ddate  =mysqli_real_escape_string($conn,$_POST['delivery_date']??'');
  $notes  =mysqli_real_escape_string($conn,trim($_POST['notes']??''));
  if(!$cid||!$dress||!$odate){$error="Customer, dress type and order date are required.";}
  else{
    mysqli_query($conn,"INSERT INTO orders(customer_id,dress_type,fabric_type,quantity,total_amount,advance_payment,remaining_amount,order_status,order_date,delivery_date,notes) VALUES($cid,'$dress','$fabric',$qty,$total,$advance,$remain,'Pending','$odate','$ddate','$notes')");
    $_SESSION['success']="Order created.";header("Location: index.php");exit;
  }
}
$customers=mysqli_query($conn,"SELECT id,customer_name FROM customers ORDER BY customer_name");
?>
<?php include '../../includes/navbar.php';?>
<div class="app-layout">
<?php include '../../includes/sidebar.php';?>
<div class="main-wrap"><div class="page-content">
<div class="page-header">
  <div class="breadcrumb-bar"><a href="../dashboard.php">Home</a><span class="sep">/</span><a href="index.php">Orders</a><span class="sep">/</span><span>Create</span></div>
  <h2>Create Order</h2>
</div>
<?php if($error):?><div class="alert-tms alert-danger-tms"><i class="bi bi-exclamation-circle"></i><?php echo $error;?></div><?php endif;?>
<div class="tms-card" style="max-width:700px;">
  <div class="tms-card-header"><h5><i class="bi bi-bag-plus me-2" style="color:var(--gold2)"></i>Order Details</h5></div>
  <div class="tms-card-body">
    <form method="POST">
      <div class="form-group"><label class="form-label-tms">Customer *</label>
        <select name="customer_id" class="form-control-tms" required>
          <option value="">— Select Customer —</option>
          <?php while($c=mysqli_fetch_assoc($customers)):?>
          <option value="<?php echo $c['id'];?>"><?php echo htmlspecialchars($c['customer_name']);?></option>
          <?php endwhile;?>
        </select></div>
      <div class="form-row">
        <div class="form-group"><label class="form-label-tms">Dress Type *</label>
          <input type="text" name="dress_type" class="form-control-tms" placeholder="Sherwani, Suit…" required></div>
        <div class="form-group"><label class="form-label-tms">Fabric Type</label>
          <input type="text" name="fabric_type" class="form-control-tms" placeholder="Silk, Khaddar…"></div>
      </div>
      <div class="form-row-3">
        <div class="form-group"><label class="form-label-tms">Quantity</label>
          <input type="number" name="quantity" class="form-control-tms" value="1" min="1"></div>
        <div class="form-group"><label class="form-label-tms">Total Amount (Rs)</label>
          <input type="number" name="total_amount" id="total" class="form-control-tms" placeholder="0" step="0.01" oninput="calcRemain()"></div>
        <div class="form-group"><label class="form-label-tms">Advance Payment (Rs)</label>
          <input type="number" name="advance_payment" id="adv" class="form-control-tms" placeholder="0" step="0.01" oninput="calcRemain()"></div>
      </div>
      <div class="form-group"><label class="form-label-tms">Remaining</label>
        <input type="text" id="rem" class="form-control-tms" readonly style="color:var(--gold2);" value="Rs 0"></div>
      <div class="form-row">
        <div class="form-group"><label class="form-label-tms">Order Date *</label>
          <input type="date" name="order_date" class="form-control-tms" value="<?php echo date('Y-m-d');?>" required></div>
        <div class="form-group"><label class="form-label-tms">Delivery Date</label>
          <input type="date" name="delivery_date" class="form-control-tms"></div>
      </div>
      <div class="form-group"><label class="form-label-tms">Notes</label>
        <textarea name="notes" class="form-control-tms" rows="2" placeholder="Special instructions…"></textarea></div>
      <div style="display:flex;gap:12px;">
        <button type="submit" class="btn-tms btn-gold"><i class="bi bi-check-lg"></i> Create Order</button>
        <a href="index.php" class="btn-tms btn-ghost"><i class="bi bi-x"></i> Cancel</a>
      </div>
    </form>
  </div>
</div>
<script>function calcRemain(){var t=parseFloat(document.getElementById('total').value)||0;var a=parseFloat(document.getElementById('adv').value)||0;document.getElementById('rem').value='Rs '+(t-a).toLocaleString();}</script>
</div></div></div>
<?php require_once '../../includes/footer.php';?>
