<?php
require_once '../../includes/auth.php';
require_once '../../config/database.php';
require_once '../../includes/header.php';
$id=(int)($_GET['id']??0);
$data=mysqli_fetch_assoc(mysqli_query($conn,"SELECT o.*,c.customer_name,c.phone,c.address FROM orders o JOIN customers c ON o.customer_id=c.id WHERE o.id=$id"));
if(!$data){header("Location: index.php");exit;}
$payments=mysqli_query($conn,"SELECT * FROM payments WHERE order_id=$id ORDER BY id DESC");
$badges=['Pending'=>'badge-pending','In Progress'=>'badge-progress','Ready'=>'badge-ready','Delivered'=>'badge-delivered','Cancelled'=>'badge-cancelled'];
$bc=$badges[$data['order_status']]??'badge-pending';
?>
<?php include '../../includes/navbar.php';?>
<div class="app-layout">
<?php include '../../includes/sidebar.php';?>
<div class="main-wrap"><div class="page-content">
<div class="page-header">
  <div class="breadcrumb-bar"><a href="../dashboard.php">Home</a><span class="sep">/</span><a href="index.php">Orders</a><span class="sep">/</span><span>View</span></div>
  <h2>Order #<?php echo $id;?></h2>
</div>
<div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:20px;">
  <div class="tms-card">
    <div class="tms-card-header">
      <h5><i class="bi bi-bag-check me-2" style="color:var(--gold2)"></i>Order Info</h5>
      <div style="display:flex;gap:8px;">
        <span class="badge-tms <?php echo $bc;?>"><?php echo $data['order_status'];?></span>
        <a href="edit.php?id=<?php echo $id;?>" class="btn-tms btn-ghost btn-sm-tms"><i class="bi bi-pencil"></i></a>
        <a href="invoice.php?id=<?php echo $id;?>" class="btn-tms btn-ghost btn-sm-tms"><i class="bi bi-receipt"></i> Invoice</a>
      </div>
    </div>
    <div class="tms-card-body" style="display:flex;flex-direction:column;gap:12px;">
      <?php
      $fields=['Customer'=>$data['customer_name'],'Phone'=>$data['phone'],'Dress Type'=>$data['dress_type'],
        'Fabric'=>$data['fabric_type']??'—','Quantity'=>$data['quantity'],
        'Total Amount'=>'Rs '.number_format($data['total_amount']),
        'Advance Paid'=>'Rs '.number_format($data['advance_payment']),
        'Remaining'=>'Rs '.number_format($data['remaining_amount']),
        'Order Date'=>date('d M Y',strtotime($data['order_date'])),
        'Delivery Date'=>$data['delivery_date']?date('d M Y',strtotime($data['delivery_date'])):'—'];
      foreach($fields as $l=>$v):?>
      <div style="display:flex;justify-content:space-between;padding-bottom:10px;border-bottom:1px solid var(--border);">
        <span style="color:var(--muted);font-size:12px;text-transform:uppercase;letter-spacing:.1em;"><?php echo $l;?></span>
        <span><?php echo htmlspecialchars((string)$v);?></span>
      </div>
      <?php endforeach;?>
    </div>
  </div>
  <div class="tms-card">
    <div class="tms-card-header"><h5><i class="bi bi-cash-coin me-2" style="color:var(--gold2)"></i>Payments</h5>
      <a href="../payments/create.php?order_id=<?php echo $id;?>" class="btn-tms btn-gold btn-sm-tms"><i class="bi bi-plus-lg"></i> Add</a></div>
    <div class="tms-table-wrap">
      <table class="tms-table">
        <thead><tr><th>Amount</th><th>Method</th><th>Date</th></tr></thead>
        <tbody>
        <?php if($payments && mysqli_num_rows($payments)>0): while($p=mysqli_fetch_assoc($payments)):?>
        <tr>
          <td style="color:var(--gold2)">Rs <?php echo number_format($p['payment_amount']);?></td>
          <td><?php echo htmlspecialchars($p['payment_method']??'—');?></td>
          <td style="color:var(--muted)"><?php echo date('d M Y',strtotime($p['payment_date']));?></td>
        </tr>
        <?php endwhile; else:?>
        <tr><td colspan="3"><div class="empty-state" style="padding:20px"><p>No payments recorded</p></div></td></tr>
        <?php endif;?>
        </tbody>
      </table>
    </div>
  </div>
</div>
</div></div></div>
<?php require_once '../../includes/footer.php';?>
