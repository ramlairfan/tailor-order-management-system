<?php
require_once '../../includes/auth.php';
require_once '../../config/database.php';
$id=(int)($_GET['id']??0);
if($id) mysqli_query($conn,"DELETE FROM payments WHERE id=$id");
$_SESSION['success']="Payment deleted.";
header("Location: index.php");exit;
