<?php
require_once '../../includes/auth.php';
require_once '../../config/database.php';
require_once '../../includes/header.php';
$result=mysqli_query($conn,"SELECT p.*,c.customer_name,o.dress_type FROM payments p JOIN orders o ON p.order_id=o.id JOIN customers c ON o.customer_id=c.id ORDER BY p.id DESC");
$bp=['Paid'=>'badge-paid','Partial'=>'badge-partial','Unpaid'=>'badge-unpaid'];
?>
<?php include '../../includes/navbar.php';?>
<div class="app-layout">
<?php include '../../includes/sidebar.php';?>
<div class="main-wrap"><div class="page-content">
<div class="page-header">
  <div class="breadcrumb-bar"><a href="../dashboard.php">Home</a><span class="sep">/</span><span>Payments</span></div>
  <h2>Payments</h2>
</div>
<?php if(isset($_SESSION['success'])):?>
<div class="alert-tms alert-success-tms"><i class="bi bi-check-circle"></i><?php echo $_SESSION['success'];unset($_SESSION['success']);?></div>
<?php endif;?>
<div class="tms-card">
  <div class="tms-card-header">
    <h5><i class="bi bi-cash-coin me-2" style="color:var(--gold2)"></i>All Payments</h5>
    <a href="create.php" class="btn-tms btn-gold"><i class="bi bi-plus-lg"></i> Add Payment</a>
  </div>
  <div class="tms-table-wrap">
    <table class="tms-table">
      <thead><tr><th>#</th><th>Customer</th><th>Order</th><th>Amount</th><th>Method</th><th>Date</th><th>Status</th><th>Actions</th></tr></thead>
      <tbody>
      <?php if($result && mysqli_num_rows($result)>0): while($row=mysqli_fetch_assoc($result)):
        $bc=$bp[$row['payment_status']]??'badge-unpaid';?>
      <tr>
        <td style="color:var(--muted)"><?php echo $row['id'];?></td>
        <td><strong><?php echo htmlspecialchars($row['customer_name']);?></strong></td>
        <td style="color:var(--muted)">Order #<?php echo $row['order_id'];?> — <?php echo htmlspecialchars($row['dress_type']);?></td>
        <td style="color:var(--gold2)">Rs <?php echo number_format($row['payment_amount']);?></td>
        <td><?php echo htmlspecialchars($row['payment_method']??'—');?></td>
        <td style="color:var(--muted)"><?php echo date('d M Y',strtotime($row['payment_date']));?></td>
        <td><span class="badge-tms <?php echo $bc;?>"><?php echo $row['payment_status'];?></span></td>
        <td style="display:flex;gap:5px;">
          <a href="view.php?id=<?php echo $row['id'];?>" class="btn-tms btn-info-tms btn-sm-tms"><i class="bi bi-eye"></i></a>
          <a href="delete.php?id=<?php echo $row['id'];?>" class="btn-tms btn-danger-tms btn-sm-tms" onclick="return confirm('Delete payment?')"><i class="bi bi-trash"></i></a>
        </td>
      </tr>
      <?php endwhile; else:?>
      <tr><td colspan="8"><div class="empty-state"><i class="bi bi-cash-coin"></i><p>No payments recorded</p></div></td></tr>
      <?php endif;?>
      </tbody>
    </table>
  </div>
</div>
</div></div></div>
<?php require_once '../../includes/footer.php';?>
