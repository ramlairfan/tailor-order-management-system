<?php
require_once '../../includes/auth.php';
require_once '../../config/database.php';
require_once '../../includes/header.php';
$preset_order=(int)($_GET['order_id']??0);
$error='';
if($_SERVER['REQUEST_METHOD']=='POST'){
  $oid   =(int)$_POST['order_id'];
  $amt   =(float)$_POST['payment_amount'];
  $method=mysqli_real_escape_string($conn,$_POST['payment_method']);
  $date  =mysqli_real_escape_string($conn,$_POST['payment_date']);
  $status=mysqli_real_escape_string($conn,$_POST['payment_status']);
  $notes =mysqli_real_escape_string($conn,trim($_POST['notes']??''));
  if(!$oid||!$amt||!$date){$error="Order, amount and date are required.";}
  else{
    mysqli_query($conn,"INSERT INTO payments(order_id,payment_amount,payment_method,payment_date,payment_status,notes) VALUES($oid,$amt,'$method','$date','$status','$notes')");
    $_SESSION['success']="Payment recorded.";header("Location: index.php");exit;
  }
}
$orders=mysqli_query($conn,"SELECT o.id,o.dress_type,c.customer_name FROM orders o JOIN customers c ON o.customer_id=c.id ORDER BY o.id DESC");
?>
<?php include '../../includes/navbar.php';?>
<div class="app-layout">
<?php include '../../includes/sidebar.php';?>
<div class="main-wrap"><div class="page-content">
<div class="page-header">
  <div class="breadcrumb-bar"><a href="../dashboard.php">Home</a><span class="sep">/</span><a href="index.php">Payments</a><span class="sep">/</span><span>Add</span></div>
  <h2>Add Payment</h2>
</div>
<?php if($error):?><div class="alert-tms alert-danger-tms"><i class="bi bi-exclamation-circle"></i><?php echo $error;?></div><?php endif;?>
<div class="tms-card" style="max-width:600px;">
  <div class="tms-card-header"><h5><i class="bi bi-cash-coin me-2" style="color:var(--gold2)"></i>Payment Details</h5></div>
  <div class="tms-card-body">
    <form method="POST">
      <div class="form-group"><label class="form-label-tms">Order *</label>
        <select name="order_id" class="form-control-tms" required>
          <option value="">— Select Order —</option>
          <?php while($o=mysqli_fetch_assoc($orders)):?>
          <option value="<?php echo $o['id'];?>" <?php if($o['id']==$preset_order) echo 'selected';?>>
            Order #<?php echo $o['id'];?> — <?php echo htmlspecialchars($o['customer_name'].' ('.$o['dress_type'].')');?>
          </option>
          <?php endwhile;?>
        </select></div>
      <div class="form-row">
        <div class="form-group"><label class="form-label-tms">Amount (Rs) *</label>
          <input type="number" name="payment_amount" class="form-control-tms" placeholder="0" step="0.01" required></div>
        <div class="form-group"><label class="form-label-tms">Method</label>
          <select name="payment_method" class="form-control-tms">
            <option>Cash</option><option>Easypaisa</option><option>JazzCash</option><option>Bank Transfer</option>
          </select></div>
      </div>
      <div class="form-row">
        <div class="form-group"><label class="form-label-tms">Date *</label>
          <input type="date" name="payment_date" class="form-control-tms" value="<?php echo date('Y-m-d');?>" required></div>
        <div class="form-group"><label class="form-label-tms">Status</label>
          <select name="payment_status" class="form-control-tms">
            <option>Paid</option><option>Partial</option><option>Unpaid</option>
          </select></div>
      </div>
      <div class="form-group"><label class="form-label-tms">Notes</label>
        <textarea name="notes" class="form-control-tms" rows="2" placeholder="Optional notes…"></textarea></div>
      <div style="display:flex;gap:12px;">
        <button type="submit" class="btn-tms btn-gold"><i class="bi bi-check-lg"></i> Save Payment</button>
        <a href="index.php" class="btn-tms btn-ghost"><i class="bi bi-x"></i> Cancel</a>
      </div>
    </form>
  </div>
</div>
</div></div></div>
<?php require_once '../../includes/footer.php';?>
