<?php
require_once '../../includes/auth.php';
require_once '../../config/database.php';
require_once '../../includes/header.php';
$id=(int)($_GET['id']??0);
$data=mysqli_fetch_assoc(mysqli_query($conn,"SELECT p.*,c.customer_name,o.dress_type FROM payments p JOIN orders o ON p.order_id=o.id JOIN customers c ON o.customer_id=c.id WHERE p.id=$id"));
if(!$data){header("Location: index.php");exit;}
$bp=['Paid'=>'badge-paid','Partial'=>'badge-partial','Unpaid'=>'badge-unpaid'];
$bc=$bp[$data['payment_status']]??'badge-unpaid';
?>
<?php include '../../includes/navbar.php';?>
<div class="app-layout">
<?php include '../../includes/sidebar.php';?>
<div class="main-wrap"><div class="page-content">
<div class="page-header">
  <div class="breadcrumb-bar"><a href="../dashboard.php">Home</a><span class="sep">/</span><a href="index.php">Payments</a><span class="sep">/</span><span>View</span></div>
  <h2>Payment #<?php echo $id;?></h2>
</div>
<div class="tms-card" style="max-width:500px;">
  <div class="tms-card-header">
    <h5><i class="bi bi-cash-coin me-2" style="color:var(--gold2)"></i>Payment Details</h5>
    <span class="badge-tms <?php echo $bc;?>"><?php echo $data['payment_status'];?></span>
  </div>
  <div class="tms-card-body" style="display:flex;flex-direction:column;gap:14px;">
    <?php $fields=['Customer'=>$data['customer_name'],'Order'=>'#'.$data['order_id'].' — '.$data['dress_type'],
      'Amount'=>'Rs '.number_format($data['payment_amount']),'Method'=>$data['payment_method']??'—',
      'Date'=>date('d M Y',strtotime($data['payment_date']))];
    foreach($fields as $l=>$v):?>
    <div style="display:flex;justify-content:space-between;padding-bottom:10px;border-bottom:1px solid var(--border);">
      <span style="color:var(--muted);font-size:12px;text-transform:uppercase;letter-spacing:.1em;"><?php echo $l;?></span>
      <span><?php echo htmlspecialchars((string)$v);?></span>
    </div>
    <?php endforeach;?>
  </div>
</div>
</div></div></div>
<?php require_once '../../includes/footer.php';?>
