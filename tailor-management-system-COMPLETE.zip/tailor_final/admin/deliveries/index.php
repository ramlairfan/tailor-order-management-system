<?php
require_once '../../includes/auth.php';
require_once '../../config/database.php';
require_once '../../includes/header.php';
$pending  =mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM orders WHERE order_status!='Delivered'"))['c'];
$delivered=mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM orders WHERE order_status='Delivered'"))['c'];
$late     =mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM orders WHERE delivery_date<CURDATE() AND order_status!='Delivered'"))['c'];
$today    =mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM orders WHERE delivery_date=CURDATE() AND order_status!='Delivered'"))['c'];
$all_orders=mysqli_query($conn,"SELECT o.*,c.customer_name FROM orders o JOIN customers c ON o.customer_id=c.id WHERE o.order_status!='Delivered' ORDER BY o.delivery_date ASC");
$badges=['Pending'=>'badge-pending','In Progress'=>'badge-progress','Ready'=>'badge-ready','Cancelled'=>'badge-cancelled'];
?>
<?php include '../../includes/navbar.php';?>
<div class="app-layout">
<?php include '../../includes/sidebar.php';?>
<div class="main-wrap"><div class="page-content">
<div class="page-header">
  <div class="breadcrumb-bar"><a href="../dashboard.php">Home</a><span class="sep">/</span><span>Deliveries</span></div>
  <h2>Delivery Management</h2>
</div>
<?php if(isset($_SESSION['success'])):?>
<div class="alert-tms alert-success-tms"><i class="bi bi-check-circle"></i><?php echo $_SESSION['success'];unset($_SESSION['success']);?></div>
<?php endif;?>
<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:18px;margin-bottom:28px;">
  <div class="stat-card"><div class="stat-icon red"><i class="bi bi-hourglass-split"></i></div>
    <div class="stat-value"><?php echo $pending;?></div><div class="stat-label">Pending</div></div>
  <div class="stat-card"><div class="stat-icon green"><i class="bi bi-check-circle"></i></div>
    <div class="stat-value"><?php echo $delivered;?></div><div class="stat-label">Delivered</div></div>
  <div class="stat-card"><div class="stat-icon red"><i class="bi bi-exclamation-triangle"></i></div>
    <div class="stat-value"><?php echo $late;?></div><div class="stat-label">Late</div></div>
  <div class="stat-card"><div class="stat-icon gold"><i class="bi bi-calendar-check"></i></div>
    <div class="stat-value"><?php echo $today;?></div><div class="stat-label">Due Today</div></div>
</div>
<div class="tms-card">
  <div class="tms-card-header"><h5><i class="bi bi-truck me-2" style="color:var(--gold2)"></i>Pending Deliveries</h5></div>
  <div class="tms-table-wrap">
    <table class="tms-table">
      <thead><tr><th>#</th><th>Customer</th><th>Dress</th><th>Delivery Date</th><th>Status</th><th>Action</th></tr></thead>
      <tbody>
      <?php if($all_orders && mysqli_num_rows($all_orders)>0): while($row=mysqli_fetch_assoc($all_orders)):
        $bc=$badges[$row['order_status']]??'badge-pending';
        $is_late=$row['delivery_date']&&$row['delivery_date']<date('Y-m-d');
        $is_today=$row['delivery_date']==date('Y-m-d');?>
      <tr <?php if($is_late) echo 'style="background:rgba(200,75,75,0.04)"'; elseif($is_today) echo 'style="background:rgba(198,151,63,0.04)"';?>>
        <td style="color:var(--muted)">#<?php echo $row['id'];?></td>
        <td><strong><?php echo htmlspecialchars($row['customer_name']);?></strong></td>
        <td><?php echo htmlspecialchars($row['dress_type']);?></td>
        <td>
          <?php if($is_late):?><span style="color:#e07070;font-weight:500;"><?php echo date('d M Y',strtotime($row['delivery_date']));?> <small>(Late)</small></span>
          <?php elseif($is_today):?><span style="color:var(--gold2);font-weight:500;"><?php echo date('d M Y',strtotime($row['delivery_date']));?> <small>(Today)</small></span>
          <?php else:?><span style="color:var(--muted)"><?php echo $row['delivery_date']?date('d M Y',strtotime($row['delivery_date'])):'Not set';?></span>
          <?php endif;?>
        </td>
        <td><span class="badge-tms <?php echo $bc;?>"><?php echo $row['order_status'];?></span></td>
        <td>
          <a href="update_status.php?id=<?php echo $row['id'];?>" class="btn-tms btn-gold btn-sm-tms" onclick="return confirm('Mark as Delivered?')"><i class="bi bi-check-lg"></i> Mark Delivered</a>
        </td>
      </tr>
      <?php endwhile; else:?>
      <tr><td colspan="6"><div class="empty-state"><i class="bi bi-truck"></i><p>All deliveries are complete!</p></div></td></tr>
      <?php endif;?>
      </tbody>
    </table>
  </div>
</div>
</div></div></div>
<?php require_once '../../includes/footer.php';?>
