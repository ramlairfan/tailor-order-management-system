<?php
require_once '../../includes/auth.php';
require_once '../../config/database.php';
require_once '../../includes/header.php';
$id=(int)($_GET['id']??0);
$data=mysqli_fetch_assoc(mysqli_query($conn,"SELECT m.*,c.customer_name FROM measurements m JOIN customers c ON m.customer_id=c.id WHERE m.id=$id"));
if(!$data){header("Location: index.php");exit;}
?>
<?php include '../../includes/navbar.php';?>
<div class="app-layout">
<?php include '../../includes/sidebar.php';?>
<div class="main-wrap"><div class="page-content">
<div class="page-header">
  <div class="breadcrumb-bar"><a href="../dashboard.php">Home</a><span class="sep">/</span><a href="index.php">Measurements</a><span class="sep">/</span><span>View</span></div>
  <h2>Measurements — <?php echo htmlspecialchars($data['customer_name']);?></h2>
</div>
<div class="tms-card" style="max-width:600px;">
  <div class="tms-card-header">
    <h5><i class="bi bi-rulers me-2" style="color:var(--gold2)"></i>Body Measurements</h5>
    <a href="edit.php?id=<?php echo $id;?>" class="btn-tms btn-ghost btn-sm-tms"><i class="bi bi-pencil"></i> Edit</a>
  </div>
  <div class="tms-card-body">
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-bottom:20px;">
      <?php foreach(['chest'=>'Chest','waist'=>'Waist','shoulder'=>'Shoulder','sleeve'=>'Sleeve','length_value'=>'Length'] as $k=>$l):?>
      <div style="background:var(--navy3);border-radius:12px;padding:18px;text-align:center;border:1px solid var(--border);">
        <div style="font-size:26px;font-weight:600;color:var(--gold2);"><?php echo $data[$k]??'—';?>"</div>
        <div style="font-size:11px;color:var(--muted);margin-top:6px;letter-spacing:.1em;text-transform:uppercase;"><?php echo $l;?></div>
      </div>
      <?php endforeach;?>
    </div>
    <?php if($data['notes']):?>
    <div style="background:var(--navy3);border-radius:10px;padding:14px;border:1px solid var(--border);">
      <p style="font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:.1em;margin-bottom:6px;">Notes</p>
      <p style="font-size:13px;"><?php echo htmlspecialchars($data['notes']);?></p>
    </div>
    <?php endif;?>
  </div>
</div>
</div></div></div>
<?php require_once '../../includes/footer.php';?>
