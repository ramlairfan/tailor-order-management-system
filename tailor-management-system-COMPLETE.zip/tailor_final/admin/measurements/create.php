<?php
require_once '../../includes/auth.php';
require_once '../../config/database.php';
require_once '../../includes/header.php';
$error='';
if($_SERVER['REQUEST_METHOD']=='POST'){
  $cid     =(int)$_POST['customer_id'];
  $chest   =mysqli_real_escape_string($conn,$_POST['chest']??'');
  $waist   =mysqli_real_escape_string($conn,$_POST['waist']??'');
  $shoulder=mysqli_real_escape_string($conn,$_POST['shoulder']??'');
  $sleeve  =mysqli_real_escape_string($conn,$_POST['sleeve']??'');
  $length  =mysqli_real_escape_string($conn,$_POST['length_value']??'');
  $notes   =mysqli_real_escape_string($conn,trim($_POST['notes']??''));
  if(!$cid){$error="Please select a customer.";}
  else{
    mysqli_query($conn,"INSERT INTO measurements(customer_id,chest,waist,shoulder,sleeve,length_value,notes) VALUES($cid,'$chest','$waist','$shoulder','$sleeve','$length','$notes')");
    $_SESSION['success']="Measurement saved.";header("Location: index.php");exit;
  }
}
$customers=mysqli_query($conn,"SELECT id,customer_name FROM customers ORDER BY customer_name");
?>
<?php include '../../includes/navbar.php';?>
<div class="app-layout">
<?php include '../../includes/sidebar.php';?>
<div class="main-wrap"><div class="page-content">
<div class="page-header">
  <div class="breadcrumb-bar"><a href="../dashboard.php">Home</a><span class="sep">/</span><a href="index.php">Measurements</a><span class="sep">/</span><span>Add</span></div>
  <h2>Add Measurement</h2>
</div>
<?php if($error):?><div class="alert-tms alert-danger-tms"><i class="bi bi-exclamation-circle"></i><?php echo $error;?></div><?php endif;?>
<div class="tms-card" style="max-width:640px;">
  <div class="tms-card-header"><h5><i class="bi bi-rulers me-2" style="color:var(--gold2)"></i>Measurement Details</h5></div>
  <div class="tms-card-body">
    <form method="POST">
      <div class="form-group"><label class="form-label-tms">Customer *</label>
        <select name="customer_id" class="form-control-tms" required>
          <option value="">— Select Customer —</option>
          <?php while($c=mysqli_fetch_assoc($customers)):?>
          <option value="<?php echo $c['id'];?>"><?php echo htmlspecialchars($c['customer_name']);?></option>
          <?php endwhile;?>
        </select></div>
      <p style="font-size:11px;letter-spacing:.15em;text-transform:uppercase;color:var(--muted);margin-bottom:14px;">All measurements in inches</p>
      <div class="form-row">
        <?php foreach(['chest'=>'Chest','waist'=>'Waist','shoulder'=>'Shoulder','sleeve'=>'Sleeve','length_value'=>'Length'] as $f=>$l):?>
        <div class="form-group"><label class="form-label-tms"><?php echo $l;?></label>
          <input type="number" name="<?php echo $f;?>" class="form-control-tms" placeholder='e.g. <?php echo $f=="chest"?"40":($f=="waist"?"34":($f=="shoulder"?"17":($f=="sleeve"?"25":"42")));?>' step="0.5"></div>
        <?php endforeach;?>
      </div>
      <div class="form-group"><label class="form-label-tms">Notes</label>
        <textarea name="notes" class="form-control-tms" rows="2" placeholder="Special notes…"></textarea></div>
      <div style="display:flex;gap:12px;">
        <button type="submit" class="btn-tms btn-gold"><i class="bi bi-check-lg"></i> Save</button>
        <a href="index.php" class="btn-tms btn-ghost"><i class="bi bi-x"></i> Cancel</a>
      </div>
    </form>
  </div>
</div>
</div></div></div>
<?php require_once '../../includes/footer.php';?>
