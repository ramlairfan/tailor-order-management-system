<?php
require_once '../../includes/auth.php';
require_once '../../config/database.php';
require_once '../../includes/header.php';
$result=mysqli_query($conn,"SELECT m.*,c.customer_name FROM measurements m JOIN customers c ON m.customer_id=c.id ORDER BY m.id DESC");
?>
<?php include '../../includes/navbar.php';?>
<div class="app-layout">
<?php include '../../includes/sidebar.php';?>
<div class="main-wrap"><div class="page-content">
<div class="page-header">
  <div class="breadcrumb-bar"><a href="../dashboard.php">Home</a><span class="sep">/</span><span>Measurements</span></div>
  <h2>Measurements</h2>
</div>
<?php if(isset($_SESSION['success'])):?>
<div class="alert-tms alert-success-tms"><i class="bi bi-check-circle"></i><?php echo $_SESSION['success'];unset($_SESSION['success']);?></div>
<?php endif;?>
<div class="tms-card">
  <div class="tms-card-header">
    <h5><i class="bi bi-rulers me-2" style="color:var(--gold2)"></i>All Measurements</h5>
    <a href="create.php" class="btn-tms btn-gold"><i class="bi bi-plus-lg"></i> Add Measurement</a>
  </div>
  <div class="tms-table-wrap">
    <table class="tms-table">
      <thead><tr><th>#</th><th>Customer</th><th>Chest</th><th>Waist</th><th>Shoulder</th><th>Sleeve</th><th>Length</th><th>Actions</th></tr></thead>
      <tbody>
      <?php if($result && mysqli_num_rows($result)>0): while($row=mysqli_fetch_assoc($result)):?>
      <tr>
        <td style="color:var(--muted)"><?php echo $row['id'];?></td>
        <td><strong><?php echo htmlspecialchars($row['customer_name']);?></strong></td>
        <td><?php echo $row['chest']??'—';?>"</td>
        <td><?php echo $row['waist']??'—';?>"</td>
        <td><?php echo $row['shoulder']??'—';?>"</td>
        <td><?php echo $row['sleeve']??'—';?>"</td>
        <td><?php echo $row['length_value']??'—';?>"</td>
        <td style="display:flex;gap:5px;">
          <a href="view.php?id=<?php echo $row['id'];?>" class="btn-tms btn-info-tms btn-sm-tms"><i class="bi bi-eye"></i></a>
          <a href="edit.php?id=<?php echo $row['id'];?>" class="btn-tms btn-ghost btn-sm-tms"><i class="bi bi-pencil"></i></a>
          <a href="delete.php?id=<?php echo $row['id'];?>" class="btn-tms btn-danger-tms btn-sm-tms" onclick="return confirm('Delete?')"><i class="bi bi-trash"></i></a>
        </td>
      </tr>
      <?php endwhile; else:?>
      <tr><td colspan="8"><div class="empty-state"><i class="bi bi-rulers"></i><p>No measurements yet</p></div></td></tr>
      <?php endif;?>
      </tbody>
    </table>
  </div>
</div>
</div></div></div>
<?php require_once '../../includes/footer.php';?>
