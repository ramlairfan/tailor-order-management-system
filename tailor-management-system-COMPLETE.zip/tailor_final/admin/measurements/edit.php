<?php
require_once '../../includes/auth.php';
require_once '../../config/database.php';
require_once '../../includes/header.php';
$id=(int)($_GET['id']??0);
$data=mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM measurements WHERE id=$id"));
if(!$data){header("Location: index.php");exit;}
if($_SERVER['REQUEST_METHOD']=='POST'){
  $cid     =(int)$_POST['customer_id'];
  $chest   =mysqli_real_escape_string($conn,$_POST['chest']??'');
  $waist   =mysqli_real_escape_string($conn,$_POST['waist']??'');
  $shoulder=mysqli_real_escape_string($conn,$_POST['shoulder']??'');
  $sleeve  =mysqli_real_escape_string($conn,$_POST['sleeve']??'');
  $length  =mysqli_real_escape_string($conn,$_POST['length_value']??'');
  $notes   =mysqli_real_escape_string($conn,trim($_POST['notes']??''));
  mysqli_query($conn,"UPDATE measurements SET customer_id=$cid,chest='$chest',waist='$waist',shoulder='$shoulder',sleeve='$sleeve',length_value='$length',notes='$notes' WHERE id=$id");
  $_SESSION['success']="Measurement updated.";header("Location: index.php");exit;
}
$customers=mysqli_query($conn,"SELECT id,customer_name FROM customers ORDER BY customer_name");
?>
<?php include '../../includes/navbar.php';?>
<div class="app-layout">
<?php include '../../includes/sidebar.php';?>
<div class="main-wrap"><div class="page-content">
<div class="page-header">
  <div class="breadcrumb-bar"><a href="../dashboard.php">Home</a><span class="sep">/</span><a href="index.php">Measurements</a><span class="sep">/</span><span>Edit</span></div>
  <h2>Edit Measurement</h2>
</div>
<div class="tms-card" style="max-width:640px;">
  <div class="tms-card-header"><h5><i class="bi bi-pencil-square me-2" style="color:var(--gold2)"></i>Edit Measurement</h5></div>
  <div class="tms-card-body">
    <form method="POST">
      <div class="form-group"><label class="form-label-tms">Customer</label>
        <select name="customer_id" class="form-control-tms">
          <?php while($c=mysqli_fetch_assoc($customers)):?>
          <option value="<?php echo $c['id'];?>" <?php if($c['id']==$data['customer_id']) echo 'selected';?>><?php echo htmlspecialchars($c['customer_name']);?></option>
          <?php endwhile;?>
        </select></div>
      <div class="form-row">
        <?php foreach(['chest'=>'Chest','waist'=>'Waist','shoulder'=>'Shoulder','sleeve'=>'Sleeve','length_value'=>'Length'] as $f=>$l):?>
        <div class="form-group"><label class="form-label-tms"><?php echo $l;?> (inches)</label>
          <input type="number" name="<?php echo $f;?>" class="form-control-tms" value="<?php echo $data[$f]??'';?>" step="0.5"></div>
        <?php endforeach;?>
      </div>
      <div class="form-group"><label class="form-label-tms">Notes</label>
        <textarea name="notes" class="form-control-tms" rows="2"><?php echo htmlspecialchars($data['notes']??'');?></textarea></div>
      <div style="display:flex;gap:12px;">
        <button type="submit" class="btn-tms btn-gold"><i class="bi bi-check-lg"></i> Update</button>
        <a href="index.php" class="btn-tms btn-ghost"><i class="bi bi-x"></i> Cancel</a>
      </div>
    </form>
  </div>
</div>
</div></div></div>
<?php require_once '../../includes/footer.php';?>
